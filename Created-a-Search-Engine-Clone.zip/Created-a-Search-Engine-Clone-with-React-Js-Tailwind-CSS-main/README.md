# Created-a-Search-Engine-Clone-with-React-Js-Tailwind-CSS
With the ability to search for up-to-date results, news, images, and videos, modern UI, dark mode, this completely responsive Google Clone with the use of modern React.js.
